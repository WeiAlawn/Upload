#!/usr/bin/env python
# _*_encoding: utf-8_*_

"""
@version: 
@author: Alawn
@license: Apache Licence 
@file: setup.py.py
@time: 2017/9/22 14:49
"""
from distutils.core import setup
import py2exe
setup(windows=['WebPanUpload.py'])