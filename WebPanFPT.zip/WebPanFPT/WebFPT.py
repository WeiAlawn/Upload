#!/usr/bin/env python
# _*_encoding: utf-8_*_

"""
@version: 
@author: Alawn
@license: Apache Licence 
@file: WebFPT.py
@time: 2017/9/20 16:38
"""
import web

urls = (
    '/', 'Index',
    '/upload', 'Upload',
)#router
render = web.template.render('templates')


class Index:
    def GET(self):
        return render.index()


class Upload:
    def POST(self):
        i = web.input(file = {}) #receive files
        filename = i.file.filename #get filename
        file = i.file.file.read() #get file
        with open('static/%s' %filename,'wb') as fn:
            fn.write(file)
        # print i
        return 'http://192.168.66.186:8080/static/%s' %filename


app = web.application(urls, globals())

if __name__ == '__main__':
    app.run()
