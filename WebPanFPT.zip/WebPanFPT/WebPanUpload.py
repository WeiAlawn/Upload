#!/usr/bin/env python
# _*_encoding: utf-8_*_

"""
@version: 
@author: Alawn
@license: Apache Licence 
@file: WebPanUpload.py
@time: 2017/9/20 16:16
"""
from Tkinter import *
import tkFileDialog
import urllib2
import win32clipboard as w
import win32con
import win32api
import tkMessageBox

def setText(text):
    w.OpenClipboard()
    w.EmptyClipboard()
    w.SetClipboardData(win32con.CF_TEXT,text)
    w.CloseClipboard()

def upload():
    filename = tkFileDialog.askopenfilename(title='选择文件')#选择文件返回文件名
    files = open(filename,'rb').read()
    data = '''------WebKitFormBoundaryocGCsY4V1sN9MfAX
Content-Disposition: form-data; name="file"; filename="%s"
Content-Type: text/plain

[file]
------WebKitFormBoundaryocGCsY4V1sN9MfAX--'''%filename.split('/')[-1]
    print data
    data = bytes(data)
    data = data.replace(bytes('[file]'),files)
    req = urllib2.Request('http://192.168.66.186:808/upload',data)
    req.add_header('Content-Type','multipart/form-data; boundary=----WebKitFormBoundaryocGCsY4V1sN9MfAX')
    html = urllib2.urlopen(req).read()
    print html

    ent.delete(0,END)
    ent.insert(0,html)

def download():
   files = urllib2.urlopen(ent.get()).read()
   filename = tkFileDialog.asksaveasfilename()
   with open(filename,'wb')as fn:
       fn.write(files)

def copy():
    setText(ent.get())
    tkMessageBox.showinfo('ok','url已复制，分享给朋友吧')

root =Tk()
root.title('文件分享系统')
root.geometry('300x130+900+300')
ent = Entry(root,width=42)
ent.grid()
btn_upload = Button(root,text='  Upload  ',command=upload)
btn_upload.grid()
btn_download = Button(root,text='Download',command=download)
btn_download.grid()
btn_copy = Button(root,text=' Copy url ',command=copy)
btn_copy.grid()
mainloop()

